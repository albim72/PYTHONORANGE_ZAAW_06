from abc import ABC, abstractmethod
import math

class Figura(ABC):
    def __init__(self,a,b):
        self.a=a
        self.b=b

    @abstractmethod
    def policz_pole(self):
        pass

class Prostokat(Figura):

    def policz_pole(self):
        return self.a*self.b


class Trojkat(Figura):

    def policz_pole(self):
        return self.a*self.b/2

pr = Prostokat(4.5,6.7)
print(f"pole prostokąta: {pr.policz_pole():.2f}")
tr = Trojkat(4.6,7.2)
print(f"pole trójkąta: {tr.policz_pole():.2f}")

class Trapez(Figura):

    def __init__(self,a,b,h):
        super().__init__(a,b)
        self.h=h

    def policz_pole(self):
        return (self.a+self.b)*self.h/2

trp = Trapez(6.6,5.2,4.8)
print(f"pole trapezu: {trp.policz_pole():.2f}")


#stwórz klasę Kolo(Figra) , policz pole koła dla promienia 5.5
#pole kola -> math.pi*a**2

class Kolo(Figura):

    def __init__(self,a):
        super().__init__(a,0)

    def policz_pole(self):
        return math.pi*self.a**2

kl = Kolo(5.5)
print(f"pole koła: {kl.policz_pole():.2f}")

