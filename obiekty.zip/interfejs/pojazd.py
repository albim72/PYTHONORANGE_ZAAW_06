from inter.ipojazd import IPojazd

class Pojazd(IPojazd):

    def spalanie(self, spal):
        return spal

    def kosztyprzejazdu(self, spal, odl, cena_l):
        return self.spalanie(spal)*odl/100*cena_l