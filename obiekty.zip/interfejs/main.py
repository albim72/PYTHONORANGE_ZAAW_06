from pojazd import Pojazd

sp = float(input("podaj spalanie na 100km: "))
od = float(input("podaj odległość w km: "))
cn = float(input("podaj cenę paliwa za litr: "))

pj = Pojazd()

print(f"spalanie na 100km = {pj.spalanie(sp)}")
print(f"koszty przejazdu na trasie {od} km wynoszą: {pj.kosztyprzejazdu(sp,od,cn):.2f} zł")

