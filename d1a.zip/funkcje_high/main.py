#funkcje wyższego rzędu

def filtrowanie(tablica,test):
    przetestowana = []
    for element in tablica:
        if(test(element)):
            przetestowana.append(element)
    return przetestowana


def czySuperLiczba(liczba):
    return liczba >= 25

pomiar = [12.8,15.4,13.6,13.9,12.1,17,18.9,19.9,22.8,20,28.9,27,13,25.5,0]

print(filtrowanie(pomiar,czySuperLiczba))


def mapowanie(tablica,transformacja):
    mapowana = []
    for element in tablica:
        mapowana.append(transformacja(element))
    return mapowana


def tempnocne(tmp):
    return tmp*0.67


nocne = list(mapowanie(pomiar,tempnocne))

temp = zip(pomiar,nocne)
listatmp = list(temp)
print(listatmp)


def potwierdzenie(imie):
    return f"potwierdzenie nadania przesyłki dla klienta: {imie}"
def odbior(imie):
    return f"potwierdzenie odbioru przesyłki przez klienta: {imie}"
def klient(funkc,imie):
    return funkc(imie)
print(klient(potwierdzenie,"Olga"))
print(klient(odbior,"Leon"))

def egzamin(jesli):
    def gratualacje():
        return "Gratulacje, zdanego egzaminu!"
    def szkoda():
        return "Przykro mi, ale następnym razem będzie lepiej"
    if jesli == "tak":
        return gratualacje()
    elif jesli == "nie":
        return szkoda()
    else:
        return " - "


print(egzamin("tak"))
print(egzamin("nie"))
print(egzamin("bla"))


