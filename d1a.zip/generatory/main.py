def liczby():
    for i in range(11):
        yield i*2

for parzysta in liczby():
    print(parzysta)

def wznow():
    print("stop!")
    yield 120
    print("start!")

    print("stop!")
    yield 310
    print("start!")

    print("stop!")
    yield 570
    print("start!")


for i in wznow():
    print(f"zwrócono wartość: {i}")

