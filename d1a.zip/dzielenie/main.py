def dziel(x,y):
    try:
        wynik = x/y
    except ZeroDivisionError:
        print("dzielenie przez 0!")
    except NameError:
        print("błąd w nazwie zmiennej")
    except Exception as exc:
        print(exc)
    else:
        print(f"wynik dzielenia: {wynik}")
    finally:
        print("policzmy coś jeszcze!")

dziel(9,4)
dziel(9,0)
dziel(0,0)
dziel(1.222,-99)
dziel(True,4)
dziel(0.00,21)
dziel("asfds",21)