import time

def pomiarczasu(funkcja):
    def wrappersy():
        starttime = time.perf_counter()
        funkcja()
        endtime = time.perf_counter()
        print(f"czas wykonania fukcji: {endtime - starttime} s")
    return wrappersy


@pomiarczasu
def sumaelementow():
    sum([i**2 for i in range(1000000)])

sumaelementow()

def budzik(funkcja):
    def wrapper():
        time.sleep(8)
        return funkcja()
    return wrapper

def debug(funkcja):
    def wrapper():
        print(f"wywołana funkcja {funkcja.__name__}")
    return wrapper

@budzik
@debug
def przypomnienie():
    print("do roboty! czas ucieka...")

przypomnienie()

