w = lambda x:2*x+11

def funcw(x):
    return 2*x+11

print(funcw(56))

print(w(56))

v = lambda x,y,z=10:(x-y)*z**2
print(v(45,12,17))
print(v(45,12))

def multi(n):
    return lambda a,b:a*n+b

print(multi(6)(7,2))

liczby = [1,2,3,4]
opis_pl = ["jeden","dwa","trzy","cztery","pięć"]
opis_en = ["one","two","three","four"]

wynik = zip(liczby,opis_pl,opis_en)
wynik_set = set(wynik)

print(wynik_set)