def pusta():
    pass

def powitanie(imie,nazwisko,miasto="Warszawa"):
    print(f"Osoba: imię: {imie}, nazwisko: {nazwisko}, miasto: {miasto}")

powitanie("Jan","Kowal","Opole")

#wyświetl funkcję powitanie podstawiając po kolei dane zwarte w kolekcji poniżej:

osoby = [
    ("Jan","Kowal","Opole"),
    ("Anna","Goral","Kraków"),
    ("Olaf","Nowak","Kraków"),
    ("Jacek","Kot","Warszawa"),
    ("Paula","Nowik","Tarnów"),
    ("Leon","Junak")


]

# for (im, nz, ms) in osoby:
#     powitanie(im,nz,ms)

for os in osoby:
    powitanie(*os)

def dokumenty(id,*args,koszty):
    print(f"id:{id},dokument wiodący: {args[0]},dokument indyentyfikacyjny: {args[1]}, "
          f"koszty administracyjne: {koszty} zł")

dokumenty(23,"UIT","EER",koszty=23)
dokumenty(27,"UIT","EER","LKK","HGG",koszty=27)
dokumenty(29,"JKO","EER","ABC",koszty=23)
dokumenty(29,"JKO","OPP",koszty=0)


f=10
def oblicz(a,b,x):
    global f
    f = (a+b)*x + f
    return f

print(f"wynik działania: {oblicz(3,12.5,6)}")
print(f)

a = 119
print(a)
print(type(a))

a = "jedynka"
print(a)
print(type(a))

