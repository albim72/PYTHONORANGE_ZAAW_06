liczby = [8,1,2,3,9,2,5,4,6,7,3,2,8,6,2,3,6,5,9]
grupa = {2,3,5,7}

def sort_prior(vart,grp):
    def helper(x):
        if x in grp:
            return (0,x)
        return (1,x)
    vart.sort(key = helper)

sort_prior(liczby,grupa)
print(liczby)