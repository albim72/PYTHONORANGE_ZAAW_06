print("to jest pierwszy skrypt")
# komentarz
"""
dokuemntacyjny
wieloliniowy
"""
wiek=36
miasto="Lublin"
imie="Karol"

dane = "Dane klienta -> imię: {}, miasto: {}, wiek {}"

print(dane.format(imie,miasto,wiek))

dane = "Dane klienta -> imię: {0}, wiek: {2}, miasto {1}"

print(dane.format(imie,miasto,wiek))

print(f"dane pracownika -> miasto: {miasto}, imię: {imie}, wiek: {wiek}")

ozn = 'mwart'
wartosc = 1.64464335

formatowanie = '%-30s = %.2f' %(ozn,wartosc)
print(formatowanie)

owoce = [
    ('awokado',8.99),
    ('truskawki',9.5),
    ('czereśnie',16),
    ('jabłka',3.55),
    ('banany',5.67)
]
print("______________________________________")
for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-10s = %.2f zł' %(i,nazwa,cena))

print("______________________________________")

for i,(nazwa,cena) in enumerate(owoce):
    print('#%d: %-10s = %.2f zł' %(
        i+1,
        nazwa.title(),
        round(cena,1)
    ))

print("______________________________________")

wynik = 67.9845474
print(f"wynik: {wynik:.2f}")