#tworzenie getter i setter w Pythonie

class Resistor:
    def __init__(self,ohms):
        self.ohms = ohms
        self.voltage = 0
        self.current = 0

r1 = Resistor(50e3)
print(f"{r1.ohms} om, {r1.voltage} v, {r1.current} a")

class VoltageResistance(Resistor):

    def __init__(self,ohms):
        super().__init__(ohms)
        self._voltage = 0

    #getter
    @property
    def voltage(self):
        return self._voltage


    #setter
    @voltage.setter
    def voltage(self,voltage):
        self._voltage = voltage
        self.current = self._voltage/self.ohms

r2 = VoltageResistance(1e3)
print(f'przed wpięciem źródła prądu: {r2.current:.2f} a')
r2.voltage = 10
print(f'po wpięciu źródła prądu: {r2.current:.2f} a')
print(f'napięcie: {r2.voltage} v')
