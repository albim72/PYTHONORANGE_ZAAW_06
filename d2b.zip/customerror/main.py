class MojaKlasaBledu(Exception):

    def __init__(self,*args):
        if args:
            self.message = args[0]
        else:
            self.message = None

    def __str__(self):
        print('wywołanie konstuktora str()')
        if self.message:
            return f'MojaKlasaBledu, {self.message}'
        else:
            return f'MojaKlasaBledu została wykonana...'


raise MojaKlasaBledu('To jest mój dziwny komunikat')