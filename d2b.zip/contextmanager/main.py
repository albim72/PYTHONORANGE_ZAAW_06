class ContextManager:

    def __init__(self):
        print('jestem kontruktorem init()')

    def __enter__(self):
        print('jestem konstruktorem enter()')
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        print('jestem konstruktorem exit()')


with ContextManager() as manager:
    print('blok instrukcji')