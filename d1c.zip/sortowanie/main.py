nazwa_classic = ['samolot','marchewka','marsz','zenit','abakus','miecz','Mieczysław','piorun',
         'Piotr','atak','lew']

nazwa_classic.sort()
print(nazwa_classic)

def sortowanie_classic(a):
    for _ in range(len(a)):
        for i in range(1,len(a)):
            if a[i] < a[i-1]:
                temp = a[i]
                a[i] = a[i-1]
                a[i-1]=temp

for i,nazwa in enumerate(nazwa_classic):
    nazwa_classic[i] = nazwa.lower()


sortowanie_classic(nazwa_classic)
print(nazwa_classic)

print("___________srotowanie z przestawieniem______________")
nazwa_modern = ['samolot','marchewka','marsz','zenit','abakus','miecz','Mieczysław','piorun',
         'Piotr','atak','lew']

def sortowanie_modern(a):
    for _ in range(len(a)):
        for i in range(1,len(a)):
            if a[i] < a[i-1]:
                a[i-1],a[i] = a[i],a[i-1]


for i,nazwa in enumerate(nazwa_modern):
    nazwa_modern[i] = nazwa.lower()


sortowanie_modern(nazwa_modern)
print(nazwa_modern)


nazwa_ekstra = ['samolot','marchewka','marsz','zenit','abakus','miecz','Mieczysław','piorun',
         'Piotr','atak','lew']

#nazwa_ekstra = [x.lower() for x in nazwa_ekstra]
print(sorted(nazwa_classic, key=lambda x:x.lower()))
#(nazwa_ekstra)
