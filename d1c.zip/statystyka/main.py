liczby = (59,99,23,45,67,89,91,21,5,68,55,45,84,92,33,1,17,49)

def pokaz_stat(dane):
    minimum = min(dane)
    maksimum = max(dane)
    rozstep = maksimum - minimum
    return minimum,maksimum,rozstep

wynik = pokaz_stat(liczby)
print(wynik)
print(type(wynik))

mini,maxi,roz = pokaz_stat(liczby)
print(f"wartość maksymalna: {maxi}, wartość minimalna: {mini},rozstęp: {roz}")

def get_srednia_odchyl(dane):
    average = sum(dane)/len(dane)
    skalowanie = [x/average for x in dane]
    skalowanie.sort(reverse=True)
    return skalowanie

najdl,*srodek,najkrot = get_srednia_odchyl(liczby)

print(f'największa wartość: {najdl:0.0%}')
print(f'największa wartość: {najkrot:0.0%}')