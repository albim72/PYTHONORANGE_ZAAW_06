def startstop(funkcja):
    def wrapper():
        print("startowanie procesu....")
        funkcja()
        print("kończenie procesu....")
    return wrapper


def zawijanie():
    print("zawijanie czekoladek w sreberka.....")

startstop(zawijanie)()

@startstop
def dmuchanie():
    print("dmuchanie balonów na imprezę....")


dmuchanie()