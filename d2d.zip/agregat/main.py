class Square:

    def __init__(self,bok):
        self.bok=bok

    def pole(self):
        return self.bok**2
class Rectangle:

    def __new__(cls, width:float, height:float):
        if width == height:
            return Square(bok = width)
        return object.__new__(Rectangle)

    def __init__(self,width:float, height:float):
        self.width = width
        self.height = height

    def pole(self):
        return self.width*self.height
r1 = Rectangle(12,7)
r2 = Rectangle(8,8)
print(type(r1))
print(type(r2))
print(f"pole = {r1.pole()}")
print(f"pole = {r2.pole()}")
