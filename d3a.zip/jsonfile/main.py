import json

jsonstr_ = '{"imie":"Jan","nazwisko":"Kot","wiek":30,"miasto":"Lublin"}'
print(jsonstr_)
print(type(jsonstr_))
strdict = json.loads(jsonstr_)
print(strdict)
print(type(strdict))
print(strdict["miasto"])
samochod = {
    "marka":"Opel",
    "model":"Insignia",
    "rocznik":2019
}

samochod["poj"] = 1.9

print(samochod)
jsonauto = json.dumps(samochod,indent=4)
print(jsonauto)
print(type(jsonauto))

with open("sam.json","w",encoding='utf-8') as f:
    f.write(jsonauto)

with open("sam.json","r",encoding='utf-8') as f:
    auto_dict = json.load(f)
print(auto_dict)
print(auto_dict["marka"])
