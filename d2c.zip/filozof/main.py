pytanie = input("Czy Ziemia jest płaska? chcesz znać odpowiedź? (t/n): ")
if pytanie.lower() == "t":
    required = True
else:
    required = False

def odpowiedz(self):
    return "Tak! Ziemia jest płaska!"
def odpowiedz_new(self):
    return "Nie! Ziemia jest okrągła!"

class SednoOdpowiedzi(type):

    def __init__(cls,clsname,superclasses,atributedict):
        if required:
            if stary:
                cls.odpowiedz = odpowiedz
            else:
                cls.odpowiedz = odpowiedz_new


pfil = input("Czy filozof jest starej daty?(t/n): ")
if pfil.lower() == "t":
    stary = True
else:
    stary = False

class Arystoteles(metaclass=SednoOdpowiedzi):
    pass

fil1 = Arystoteles()
print(fil1.odpowiedz())

pfil = input("Czy filozof jest starej daty?(t/n): ")
if pfil.lower() == "t":
    stary = True
else:
    stary = False

class Platon(metaclass=SednoOdpowiedzi):
    pass

fil2 = Platon()
print(fil2.odpowiedz())

pfil = input("Czy filozof jest starej daty?(t/n): ")
if pfil.lower() == "t":
    stary = True
else:
    stary = False

class SwTomasz(metaclass=SednoOdpowiedzi):
    pass

fil3 = SwTomasz()
print(fil3.odpowiedz())

pfil = input("Czy filozof jest starej daty?(t/n): ")
if pfil.lower() == "t":
    stary = True
else:
    stary = False

class Kopernik(metaclass=SednoOdpowiedzi):
    pass

fil4 = Kopernik()
print(fil4.odpowiedz())

#Stórz klasę Kopernik opartą o metaklasę SednoOdpowiedzi i zmień komunikat w metodzie odpowiedz na
#"Nie! Ziemia jest okrągła"