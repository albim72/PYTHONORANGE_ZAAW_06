#stwórz klasę wyjątku obsługująca słownik, z zastrzerzeniem konkretnych uwarunkowań:
#1. wartości słownika mogą przyjmować tylko wartości typu int lub float
#2. do konstrukcji słownika użyj listy zwierającej inne listy lub krotki
#pierwsza pozycja listy: klucze, druga: wartości

class IntFloatValueError(Exception):

    def __init__(self,value):
        self.value = value

    def __str__(self):
        return f'{self.value} jest niwłaściwe. Akceptowalne typy to: int i float'

class KeyValueConstructError(Exception):
    def __init__(self,key,value):
        self.key = key
        self.value = value

    def __str__(self):
        return f'klucze i wartości powinny należeć do grupy: lista, krotka, ' \
               f'kolekcja kluczy {self.key} jest w typie {type(self.key)},' \
               f'kolekacja wartości {self.value}, jest w typie {type(self.value)}'

class CustomInfloatDict(dict):
    empty_dict = {}

    def __init__(self,key=None, value=None):

        if key is None or value is None:
            self.get_dict()
        elif not isinstance(key,(tuple,list,)) or not isinstance(value,(tuple,list,)):
            raise KeyValueConstructError(key,value)
        else:
            zipped = zip(key,value)
            for k, val in zipped:
                if not isinstance(val,(int,float)):
                    raise IntFloatValueError(val)
                dict.__setitem__(self,k,val)

    def get_dict(self):
        return self.empty_dict

    def __setitem__(self, key, value):
        if not isinstance(value, (int, float)):
            raise IntFloatValueError(value)
        return dict.__setitem__(self,key,value)

#testowanie
test_1 = CustomInfloatDict()
print(test_1)

# test_2 = CustomInfloatDict({'a','b'},[1,4])
# print(test_2)

# test_3 = CustomInfloatDict(('x','y','z'),[21,'osiem',91])
# print(test_3)

test_4 = CustomInfloatDict(('x','y','z'),(10,78,3))
print(test_4)

test_5 = CustomInfloatDict(('x','y','z'),(10,78,True))
print(test_5)


